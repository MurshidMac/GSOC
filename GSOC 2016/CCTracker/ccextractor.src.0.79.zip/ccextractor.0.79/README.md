ccextractor
===========

Carlos' version (mainstream) is the most stable branch.

Extracting subtitles has never been so easy. Just type the following command:
ccextrator "name of input"

Gui lovers should download the Sorceforge version of CCExtractor, the Git Version is not your cup of tea.
http://ccextractor.sourceforge.net/download-ccextractor.html

For News about release, please find CHANGES.TXT
