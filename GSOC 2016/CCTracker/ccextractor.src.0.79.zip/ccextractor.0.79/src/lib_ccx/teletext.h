/*!
(c) 2011-2013 Forers, s. r. o.: telxcc
*/

#ifndef teletext_h_included
#define teletext_h_included

//#include <inttypes.h>


int tlt_print_seen_pages(struct lib_cc_decode *dec_ctx);
#endif
