#define AUDIO 		1
#define INPUT		1
#define VIDEO		1
