# beagleusb
Beagleboard USB driver for Mouse, Keyboard, Audio playback


This Repository is an integration of three different drivers-Audio, Input & Framebuffer driver

Individual startup repository available at:
https://github.com/azizulhakim/beagledroid-usbaudio
https://github.com/azizulhakim/beagledroid-kbd
https://github.com/azizulhakim/bard-linux

Test instructions are added inside "docs/How to Test.html"
