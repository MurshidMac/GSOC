bard-droid
===========================

Android remote display for Beagle bone Android application source. This is a proposal for Google Summer of Code 2014 under Beagle.org. The complete proposal can be accessed at http://blog.praveenkumar.co.in/2014/05/gsoc-14-proposal-for-beagleorg.html
